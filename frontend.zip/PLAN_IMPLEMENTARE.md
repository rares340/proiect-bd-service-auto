# Plan Detaliat de Implementare - Service Auto & Stație ITP

## 1. Arhitectură Generală (3-Tier)
Aplicația este structurată pe trei niveluri independente:
*   **Tier 1 - Interfață Utilizator:** Desktop Client în **PyQt6** (comunică exclusiv prin HTTP REST cu backend-ul, folosind `httpx`).
*   **Tier 2 - Backend & Logică de Business:** **FastAPI** în Python, implementat **sincron** (pentru simplitate și claritate), validare de date cu **Pydantic v2**, driver PostgreSQL nativ `psycopg3` cu `ConnectionPool` (fără ORM, SQL brut). Include și modulul de Machine Learning.
*   **Tier 3 - Persistență Date:** Bază de date relațională **PostgreSQL** (13 tabele, constrângeri `CHECK`, chei străine și indecși).

---

## 2. Etape de Implementare și Status

### Faza 1: Bază de Date & DDL (Finalizată)
- [x] Structură completă definită în `sql/tabele_service.sql` (13 tabele).
- [x] Tabele principale: `CLIENT`, `ANGAJAT`, `UTILIZATOR`, `VEHICUL`, `LUCRARE_CATALOG`, `FURNIZOR`, `PIESA`, `COMANDA_REPARATIE`, `PROGRAMARE`, `LUCRARE_EFECTUATA`, `PIESA_COMANDA`, `INSPECTIE_ITP`, `RECOMANDARE_DIAGNOZA`.
- [x] Constrângeri de integritate:
  - Verificare lungime serie șasiu (exact 17 caractere).
  - Valori permise pentru combustibil, status comandă, roluri utilizator etc.
  - Constrângeri logice: `km >= 0`, `stoc_curent >= 0`, `pret_vanzare >= 0`.
  - Constrângere ITP: dacă rezultatul este `ADMIS`, `data_expirare` trebuie să fie completată și posterioară datei inspecției; dacă e `RESPINS`, data de expirare este `NULL`.
- [x] Indecși optimizați pe coloanele frecvent căutate / chei străine.

---

### Faza 2: Conexiune DB & Core Backend (Finalizată)
- [x] Dependențe backend în `backend/requirements.txt`:
  - `fastapi`, `uvicorn` (server REST).
  - `psycopg[binary]`, `psycopg-pool` (driver și pool conexiuni PostgreSQL).
  - `pydantic`, `pydantic-settings` (validare și parsare scheme de date).
  - `python-dotenv` (gestionare configurări și secrete).
  - `scikit-learn`, `pandas` (modul AI).
  - `httpx` (client HTTP).
- [x] Conexiune și Pooling în `backend/db.py`:
  - Gestionare conexiuni prin `ConnectionPool` sincron.
  - Utilizare `dict_row` pentru returnarea automată a rezultatelor SQL sub formă de dicționare Python.
  - Generatorul de context `get_db()` pentru injecție curată de dependențe în rute.
- [x] Fișier șablon configurare `backend/.env.example`.
- [x] Scheme Pydantic v2 în `backend/schemas.py`:
  - Autentificare: `UserLogin`, `UserResponse`.
  - Gestiune clienți: `ClientCreate`, `ClientResponse`.
  - Gestiune vehicule: `VehiculCreate`, `VehiculResponse`.
  - Comenzi service: `ComandaCreate`, `ComandaResponse`.
  - Inspecție ITP: `InspectieITPCreate`, `InspectieITPResponse`.

---

### Faza 3: Rute REST API (`backend/main.py`) (În curs de pregătire)
- [ ] **Autentificare simplă:**
  - `POST /api/login`: Verifică `nume_utilizator` și `parola` în tabelul `utilizator`. Returnează ID-ul, rolul (`ADMINISTRATOR`, `OPERATOR`, `INSPECTOR`) și datele angajatului asociat. Fără token-uri complexe (autentificare pe bază de sesiune/header simplu).
- [ ] **CRUD Clienți & Vehicule:**
  - `GET /api/clienti`: Căutare după nume/telefon sau listare toți.
  - `POST /api/clienti`: Adăugare client nou.
  - `GET /api/vehicule`: Listare vehicule (opțional filtrate după client).
  - `POST /api/vehicule`: Înregistrare vehicul nou asociat unui client.
- [ ] **Gestiune Comenzi Reparație:**
  - `POST /api/comenzi`: Deschidere comandă de lucru asociată unui vehicul și preluată de un operator.
  - `POST /api/comenzi/{id_comanda}/piese`: Adăugare piesă pe comandă.
    - Execuție într-o tranzacție SQL: adăugare în `piesa_comanda` + scădere stoc din `piesa`.
    - Alertă dacă `stoc_curent` ajunge sub `prag_minim`.
  - `PATCH /api/comenzi/{id_comanda}/status`: Modificare status (`DESCHISA` -> `IN_LUCRU` -> `FINALIZATA` -> `PREDATA`).
- [ ] **Modul Inspecție ITP:**
  - `POST /api/itp`: Înregistrare măsurători stand (noxe CO, eficiență frânare, convergență).
  - Logică de calcul pe backend:
    - Decizie automată `ADMIS` / `RESPINS` pe baza limitelor legale (emisii, frânare).
    - Calcul automat `data_expirare` pe baza vechimii mașinii:
      - Mașini noi (≤ 3-4 ani): valabilitate 3 sau 2 ani.
      - Mașini uzuale: valabilitate 1 an sau 2 ani conform legislației.
    - Salvarea rezultatului în tabelul `inspectie_itp`.

---

### Faza 4: Modul AI Diagnoză & Mentenanță Predictivă (`backend/ml_diagnoza.py`)
- [ ] **Date de Antrenare:**
  - Extragere istoric intervenții din baza de date prin interogare SQL: îmbinare `vehicul` (marcă, model, an, combustibil, km) cu `lucrare_efectuata` și `lucrare_catalog`.
- [ ] **Model Machine Learning:**
  - Folosire `RandomForestClassifier` din `scikit-learn`.
  - **Features (Input):** `marca`, `model`, `combustibil`, `an_fabricatie`, `km_intrare`.
  - **Target (Output):** Categorie lucrare / piesă cu probabilitate ridicată de defect (ex: *Sistem Frânare*, *Direcție/Suspensie*, *Distribuție*).
- [ ] **Ruta API AI:**
  - `POST /api/diagnoza/{id_vehicul}`:
    - Preia datele mașinii din DB.
    - Rulează modelul antrenat și obține probabilitatea/scorul de risc.
    - Inserează predicția în tabelul `recomandare_diagnoza` (`categorie`, `scor_risc`, `algoritm = 'RandomForest'`).
    - Returnează recomandarea către aplicația desktop pentru afișare.

---

### Faza 5: Client Desktop PyQt6 (`client_desktop/`)
- [ ] **Configurare mediu desktop:**
  - `client_desktop/requirements.txt`: `PyQt6`, `httpx`.
  - `client_desktop/session.py`: Singleton/clasă globală care reține utilizatorul curent, token-ul/header-ul și rolul activ.
- [ ] **Ecran Login (`client_desktop/views_login.py`):**
  - Formular de autentificare.
  - Direcționare automată către ecranul corespunzător rolului utilizatorului.
- [ ] **Panou Operator Service (`client_desktop/views_operator.py`):**
  - **Tab Clienți & Vehicule:** Formulare de căutare, vizualizare istoric și adăugare rapidă.
  - **Tab Comenzi:** Deschidere comandă, adăugare lucrări și piese.
  - **Alerte Stoc:** Indicator vizual cu piese aflate sub pragul minim.
  - **Recomandări AI:** Panou vizual care afișează alertele de mentenanță predictivă generate de model.
- [ ] **Panou Inspector ITP (`client_desktop/views_itp.py`):**
  - Selectare vehicul după număr de înmatriculare.
  - Introducere date de la stand (emisii CO, frâne).
  - Răspuns vizual instantaneu: card verde/roșu cu decizia `ADMIS` / `RESPINS` și data expirării calculată.
- [ ] **Punct de intrare (`client_desktop/main.py`):**
  - Lansarea buclei principale PyQt6 și încărcarea stilurilor grafice.
